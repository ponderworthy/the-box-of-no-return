
//fix build error in KitKat

#define	_U	_CTYPE_U
#define	_L	_CTYPE_L
#define	_N	_CTYPE_N
#define	_S	_CTYPE_S
#define	_P	_CTYPE_P
#define	_C	_CTYPE_C
#define	_X	_CTYPE_X
#define	_B	_CTYPE_B

#include <../../../../../../../../../../../prebuilts/ndk/current/sources/cxx-stl/gnu-libstdc++/libs/armeabi-v7a/include/bits/ctype_base.h>


#! /usr/bin/env python
# encoding: utf-8
# WARNING! Do not edit! https://waf.io/book/index.html#_obtaining_the_waf_file

import os,re,threading
from waflib import Task,Logs,Utils,Errors
from waflib.Tools import c_preproc
from waflib.TaskGen import before_method,feature
lock=threading.Lock()
gccdeps_flags=['-MD']
if not c_preproc.go_absolute:
	gccdeps_flags=['-MMD']
supported_compilers=['gcc','icc','clang']
def scan(self):
	if not self.__class__.__name__ in self.env.ENABLE_GCCDEPS:
		return super(self.derived_gccdeps,self).scan()
	nodes=self.generator.bld.node_deps.get(self.uid(),[])
	names=[]
	return(nodes,names)
re_o=re.compile(r"\.o$")
re_splitter=re.compile(r'(?<!\\)\s+')
def remove_makefile_rule_lhs(line):
	rulesep=': '
	sep_idx=line.find(rulesep)
	if sep_idx>=0:
		return line[sep_idx+2:]
	else:
		return line
def path_to_node(base_node,path,cached_nodes):
	if getattr(path,'__hash__'):
		node_lookup_key=(base_node,path)
	else:
		node_lookup_key=(base_node,os.path.sep.join(path))
	try:
		lock.acquire()
		node=cached_nodes[node_lookup_key]
	except KeyError:
		node=base_node.find_resource(path)
		cached_nodes[node_lookup_key]=node
	finally:
		lock.release()
	return node
def post_run(self):
	if not self.__class__.__name__ in self.env.ENABLE_GCCDEPS:
		return super(self.derived_gccdeps,self).post_run()
	name=self.outputs[0].abspath()
	name=re_o.sub('.d',name)
	try:
		txt=Utils.readf(name)
	except EnvironmentError:
		Logs.error('Could not find a .d dependency file, are cflags/cxxflags overwritten?')
		raise
	txt='\n'.join([remove_makefile_rule_lhs(line)for line in txt.splitlines()])
	txt=txt.replace('\\\n','')
	val=txt.strip()
	val=[x.replace('\\ ',' ')for x in re_splitter.split(val)if x]
	nodes=[]
	bld=self.generator.bld
	try:
		cached_nodes=bld.cached_nodes
	except AttributeError:
		cached_nodes=bld.cached_nodes={}
	for x in val:
		node=None
		if os.path.isabs(x):
			node=path_to_node(bld.root,x,cached_nodes)
		else:
			path=getattr(bld,'cwdx',bld.bldnode)
			x=[k for k in Utils.split_path(x)if k and k!='.']
			while'..'in x:
				idx=x.index('..')
				if idx==0:
					x=x[1:]
					path=path.parent
				else:
					del x[idx]
					del x[idx-1]
			node=path_to_node(path,x,cached_nodes)
		if not node:
			raise ValueError('could not find %r for %r'%(x,self))
		if id(node)==id(self.inputs[0]):
			continue
		nodes.append(node)
	Logs.debug('deps: gccdeps for %s returned %s',self,nodes)
	bld.node_deps[self.uid()]=nodes
	bld.raw_deps[self.uid()]=[]
	try:
		del self.cache_sig
	except AttributeError:
		pass
	Task.Task.post_run(self)
def sig_implicit_deps(self):
	if not self.__class__.__name__ in self.env.ENABLE_GCCDEPS:
		return super(self.derived_gccdeps,self).sig_implicit_deps()
	try:
		return Task.Task.sig_implicit_deps(self)
	except Errors.WafError:
		return Utils.SIG_NIL
def wrap_compiled_task(classname):
	derived_class=type(classname,(Task.classes[classname],),{})
	derived_class.derived_gccdeps=derived_class
	derived_class.post_run=post_run
	derived_class.scan=scan
	derived_class.sig_implicit_deps=sig_implicit_deps
for k in('c','cxx'):
	if k in Task.classes:
		wrap_compiled_task(k)
@before_method('process_source')
@feature('force_gccdeps')
def force_gccdeps(self):
	self.env.ENABLE_GCCDEPS=['c','cxx']
def configure(conf):
	if not getattr(conf.options,'enable_gccdeps',True):
		return
	global gccdeps_flags
	flags=conf.env.GCCDEPS_FLAGS or gccdeps_flags
	if conf.env.CC_NAME in supported_compilers:
		try:
			conf.check(fragment='int main() { return 0; }',features='c force_gccdeps',cflags=flags,msg='Checking for c flags %r'%''.join(flags))
		except Errors.ConfigurationError:
			pass
		else:
			conf.env.append_value('CFLAGS',flags)
			conf.env.append_unique('ENABLE_GCCDEPS','c')
	if conf.env.CXX_NAME in supported_compilers:
		try:
			conf.check(fragment='int main() { return 0; }',features='cxx force_gccdeps',cxxflags=flags,msg='Checking for cxx flags %r'%''.join(flags))
		except Errors.ConfigurationError:
			pass
		else:
			conf.env.append_value('CXXFLAGS',flags)
			conf.env.append_unique('ENABLE_GCCDEPS','cxx')
def options(opt):
	raise ValueError('Do not load gccdeps options')

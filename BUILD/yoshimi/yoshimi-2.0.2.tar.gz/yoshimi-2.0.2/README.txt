Version 2.0.2

This release contains the new (part complete) User guide. It also has various bugfixes and minor improvements.

Yoshimi source code is available from either:
https://sourceforge.net/projects/yoshimi
Or:
https://github.com/Yoshimi/yoshimi

Full build instructions are in 'INSTALL'.

Our list archive is at:
https://www.freelists.org/archive/yoshimi
To post, email to:
yoshimi@freelists.org

#include "Misc/Splash.h"

const int splashWidth = 480;
const int splashHeight = 320;

const unsigned char splashPngData[] = {
#include "Misc/SplashPngHex"
};

const unsigned int splashPngLength = 85082;

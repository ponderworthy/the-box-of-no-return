#ifndef SPLASH_H
#define SPLASH_H

#ifdef __cplusplus
extern "C" {
#endif

  extern const int splashWidth;
  extern const int splashHeight;
  extern const unsigned char splashPngData[];
  extern const unsigned int splashPngLength;

#ifdef __cplusplus
}
#endif
#endif

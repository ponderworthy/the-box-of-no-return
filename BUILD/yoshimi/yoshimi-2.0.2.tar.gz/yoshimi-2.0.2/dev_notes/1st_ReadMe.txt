
If you haven't read O_WARNING_O please do so now.

Some general notes on new developments as they occur.

Please pay particular attention to Gui_Interpretations.txt and Yoshimi Control Numbers.ods

Finally, this is still a moving target and the numbers may change. globals.h will give the actual labels and their numbers. Hopefully the time will come when the numbers are no longer relevant at all.

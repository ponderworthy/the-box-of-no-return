This 'Examples' directory is most likely to be in either:
/usr/local/share/yoshimi/
or:
/usr/share/yoshimi/

The same applies to 'Banks' and 'Presets'.

These locations are not normally writable, meaning you can't make changes. Therefore it is a good idea to create a working directory in your 'home' one and copy all of these across.

These is also some additional information either in:
/usr/local/share/doc/yoshimi
or:
/usr/share/doc/yoshimi

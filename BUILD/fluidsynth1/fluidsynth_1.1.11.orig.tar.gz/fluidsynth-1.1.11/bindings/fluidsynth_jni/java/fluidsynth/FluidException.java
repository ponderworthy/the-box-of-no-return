package fluidsynth;

public class FluidException extends Exception
{
    public FluidException(String what) {
	super(what);
    }
}

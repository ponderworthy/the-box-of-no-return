# Misc Icons

Currently these SVG icons are used in the about dialog, the script with the json
to generate the related truetype font.

The GitHub, Discord and Open Collective SVG comes from the [Simple Icons]
collection.

All the icons are licensed under the [Creative Common 0 License],
see the included [license] file.

[license]: LICENSE.md
[Simple Icons]: https://github.com/simple-icons/simple-icons/
[Creative Common 0 License]: https://creativecommons.org/publicdomain/zero/1.0/

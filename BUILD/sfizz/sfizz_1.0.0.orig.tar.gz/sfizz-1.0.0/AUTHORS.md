# Author and contributors

Contributors to `sfizz`, in chronologic order:

- Paul Ferrand (2019-2020) (maintainer)
- Andrea Zanellato (2019-2020) (devops, documentation and distribution)
- Alexander Mitchell (2020)
- Michael Willis (2020)
- Jean-Pierre Cimalando (2020)
- Tobiasz "unfa" Karoń (2020)
- Kinwie (2020)
- Atsushi Eno (2020)
- Dominique Würtz (2021)
